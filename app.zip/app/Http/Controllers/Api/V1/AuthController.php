<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Mail\OtpMail;
use App\Models\ClubMembership;
use App\Models\ClubMembershipRequest;
use App\Models\User;
use App\Support\ApiErrorCode;
use App\Support\ApiValidationRules;
use App\Support\AuditLogger;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rules\Password;
use Spatie\Permission\Models\Role;

class AuthController extends Controller
{
    public function registerPlayer(Request $request): JsonResponse
    {
        $email = strtolower($request->string('email')->toString());
        $phone = $request->string('phone')->toString();

        if (User::where('email', $email)->exists()) {
            return $this->errorResponse(
                'Email already exists.',
                ApiErrorCode::EMAIL_ALREADY_EXISTS,
                ['email' => ['The email has already been taken.']],
                409
            );
        }

        if (User::where('phone', $phone)->exists()) {
            return $this->errorResponse(
                'Phone number already exists.',
                ApiErrorCode::PHONE_ALREADY_EXISTS,
                ['phone' => ['The phone has already been taken.']],
                409
            );
        }

        $validator = Validator::make($request->all(), [
            'full_name' => ['required', 'string', 'max:255'],
            'email' => [...ApiValidationRules::email(), 'max:255'],
            'phone' => ApiValidationRules::phone(),
            'password' => ['required', Password::min(8)],
            'club_memberships' => ['nullable', 'array'],
            'club_memberships.*.club_id' => [
                'required_with:club_memberships',
                'integer',
                'distinct',
                \Illuminate\Validation\Rule::exists('users', 'id')->where(function ($query) {
                    $query->where('role', 'club')->where('status', 'active');
                }),
            ],
            'club_memberships.*.membership_number' => [
                'required_with:club_memberships.*.club_id',
                'string',
                'max:255',
            ],
            'are_you_scorer' => ['nullable', 'boolean'],
            'are_you_umpire' => ['nullable', 'boolean'],
        ]);

        if ($validator->fails()) {
            return $this->validationError($validator->errors()->toArray());
        }

        DB::beginTransaction();
        try {
            $user = User::create([
                'name' => $request->string('full_name')->toString(),
                'email' => $email,
                'phone' => $phone,
                'password' => Hash::make($request->string('password')->toString()),
                'role' => 'player',
                'status' => 'otp_pending',
                'otp_verified' => false,
                'are_you_scorer' => $request->boolean('are_you_scorer'),
                'are_you_umpire' => $request->boolean('are_you_umpire'),
            ]);

            $plainAccessToken = bin2hex(random_bytes(32));
            $plainRefreshToken = bin2hex(random_bytes(32));

            $user->api_access_token = hash('sha256', $plainAccessToken);
            $user->api_refresh_token = hash('sha256', $plainRefreshToken);
            $user->save();

            $this->assignRoleIfPresent($user, 'player');
            $this->createOtp($user->email, 'registration');

            // Store club memberships requests transactionally
            if ($request->has('club_memberships') && is_array($request->input('club_memberships'))) {
                foreach ($request->input('club_memberships') as $membership) {
                    if (isset($membership['club_id']) && isset($membership['membership_number'])) {
                        ClubMembershipRequest::create([
                            'club_id' => $membership['club_id'],
                            'player_id' => $user->id,
                            'membership_number' => $membership['membership_number'],
                            'status' => ClubMembershipRequest::STATUS_PENDING,
                        ]);
                    }
                }
            }

            DB::commit();
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
        }

        return response()->json([
            'success' => true,
            'message' => 'Player registered successfully. OTP sent to email.',
            'data' => [
                'access_token' => $plainAccessToken,
                'refresh_token' => $plainRefreshToken,
                'user' => [
                    'id' => $user->id,
                    'role' => $user->role,
                    'email' => $user->email,
                    'status' => $user->status,
                    'otp_verified' => (bool) $user->otp_verified,
                    'profile_completed' => $this->isPlayerProfileCompleted($user),
                ],
            ],
        ], 201);
    }

    public function registerClub(Request $request): JsonResponse
    {
        $email = strtolower($request->string('email')->toString());
        $phone = $request->string('phone')->toString();

        if (User::where('email', $email)->exists()) {
            return $this->errorResponse(
                'Email already exists.',
                ApiErrorCode::EMAIL_ALREADY_EXISTS,
                ['email' => ['The email has already been taken.']],
                409
            );
        }

        if (User::where('phone', $phone)->exists()) {
            return $this->errorResponse(
                'Phone number already exists.',
                ApiErrorCode::PHONE_ALREADY_EXISTS,
                ['phone' => ['The phone has already been taken.']],
                409
            );
        }

        $isLegacy = is_string($request->input('working_hours'));

        if ($isLegacy) {
            $rules = [
                'club_name' => ['required', 'string', 'max:255'],
                'owner_manager_name' => ['required', 'string', 'max:255'],
                'email' => [...ApiValidationRules::email(), 'max:255'],
                'phone' => ApiValidationRules::phone(),
                'address' => ['required', 'string', 'max:255'],
                'city' => ['required', 'string', 'max:100'],
                'number_of_courts' => ApiValidationRules::numberOfCourts(),
                'working_hours' => ['required', 'string', 'max:100'],
                'password' => ['required', Password::min(8)],
                'club_logo' => ['nullable', 'file', 'mimes:jpg,jpeg,png,webp'],
                'facilities' => ['nullable', 'array'],
                'facilities.*' => ['string', 'max:255'],
                
                // Booking policy fields
                'non_member_booking' => ['nullable', 'array'],
                'non_member_booking.allowed' => ['required_with:non_member_booking', 'boolean'],
                'non_member_booking.start_time' => [
                    'required_if:non_member_booking.allowed,true,1',
                    'nullable',
                    'date_format:H:i',
                ],
                'non_member_booking.end_time' => [
                    'required_if:non_member_booking.allowed,true,1',
                    'nullable',
                    'date_format:H:i',
                    'after:non_member_booking.start_time',
                ],
                'non_member_booking.timezone' => [
                    'required_if:non_member_booking.allowed,true,1',
                    'nullable',
                    'string',
                    'timezone',
                ],
                
                // Initial player IDs
                'initial_player_ids' => ['nullable', 'array'],
                'initial_player_ids.*' => [
                    'integer',
                    'distinct',
                    \Illuminate\Validation\Rule::exists('users', 'id')->where(function ($query) {
                        $query->where('role', 'player');
                    }),
                ],
                'members' => ['nullable', 'array'],
                'members.*.player_id' => [
                    'required_with:members',
                    'integer',
                    'distinct',
                    \Illuminate\Validation\Rule::exists('users', 'id')->where(function ($query) {
                        $query->where('role', 'player');
                    }),
                ],
                'members.*.membership_number' => [
                    'required_with:members',
                    'string',
                    'distinct',
                    'max:255',
                ],
            ];
            
            $validator = Validator::make($request->all(), $rules);
            
            $validator->after(function ($validator) use ($request) {
                $allowed = $request->input('non_member_booking.allowed');
                if ($allowed !== null && !filter_var($allowed, FILTER_VALIDATE_BOOLEAN)) {
                    if ($request->filled('non_member_booking.start_time')) {
                        $validator->errors()->add('non_member_booking.start_time', 'The start time must be null when non-member booking is not allowed.');
                    }
                    if ($request->filled('non_member_booking.end_time')) {
                        $validator->errors()->add('non_member_booking.end_time', 'The end time must be null when non-member booking is not allowed.');
                    }
                    if ($request->filled('non_member_booking.timezone')) {
                        $validator->errors()->add('non_member_booking.timezone', 'The timezone must be null when non-member booking is not allowed.');
                    }
                }
            });
        } else {
            $rules = [
                'club_name' => ['required', 'string', 'max:255'],
                'owner_manager_name' => ['required', 'string', 'max:255'],
                'email' => [...ApiValidationRules::email(), 'max:255'],
                'phone' => ApiValidationRules::phone(),
                'address' => ['required', 'string', 'max:255'],
                'city' => ['required', 'string', 'max:100'],
                'number_of_courts' => ApiValidationRules::numberOfCourts(),
                'password' => ['required', Password::min(8)],
                'club_logo' => ['nullable', 'file', 'mimes:jpg,jpeg,png,webp'],
                'facilities' => ['nullable', 'array'],
                'facilities.*' => ['string', 'max:255'],
                'timezone' => ['required', 'string', 'timezone'],

                // New Day-wise club working hours
                'working_hours' => ['required', 'array', 'min:7', 'max:7'],
                'working_hours.*.day' => ['required', 'string', 'in:monday,tuesday,wednesday,thursday,friday,saturday,sunday'],
                'working_hours.*.is_open' => ['required', 'boolean'],
                'working_hours.*.opens_at' => ['required_if:working_hours.*.is_open,true,1', 'nullable', 'date_format:H:i'],
                'working_hours.*.closes_at' => ['required_if:working_hours.*.is_open,true,1', 'nullable', 'date_format:H:i'],

                // New Non-member booking fields
                'allow_non_member_booking' => ['required', 'boolean'],
                'non_member_booking_schedule' => ['required_if:allow_non_member_booking,true,1', 'nullable', 'array', 'min:7', 'max:7'],
                'non_member_booking_schedule.*.day' => ['required_with:non_member_booking_schedule', 'string', 'in:monday,tuesday,wednesday,thursday,friday,saturday,sunday'],
                'non_member_booking_schedule.*.is_available' => ['required_with:non_member_booking_schedule', 'boolean'],
                'non_member_booking_schedule.*.time_ranges' => ['required_if:non_member_booking_schedule.*.is_available,true,1', 'nullable', 'array'],
                'non_member_booking_schedule.*.time_ranges.*.from' => ['required_with:non_member_booking_schedule.*.time_ranges', 'date_format:H:i'],
                'non_member_booking_schedule.*.time_ranges.*.to' => ['required_with:non_member_booking_schedule.*.time_ranges', 'date_format:H:i'],

                // Initial player IDs
                'initial_player_ids' => ['nullable', 'array'],
                'initial_player_ids.*' => [
                    'integer',
                    'distinct',
                    \Illuminate\Validation\Rule::exists('users', 'id')->where(function ($query) {
                        $query->where('role', 'player');
                    }),
                ],
                'members' => ['nullable', 'array'],
                'members.*.player_id' => [
                    'required_with:members',
                    'integer',
                    'distinct',
                    \Illuminate\Validation\Rule::exists('users', 'id')->where(function ($query) {
                        $query->where('role', 'player');
                    }),
                ],
                'members.*.membership_number' => [
                    'required_with:members',
                    'string',
                    'distinct',
                    'max:255',
                ],
            ];

            $validator = Validator::make($request->all(), $rules);

            $validator->after(function ($validator) use ($request) {
                $workingHours = $request->input('working_hours');
                $allowNonMember = filter_var($request->input('allow_non_member_booking', false), FILTER_VALIDATE_BOOLEAN);
                $nonMemberSchedule = $request->input('non_member_booking_schedule');

                if (!is_array($workingHours)) {
                    return;
                }

                // 1. One record per day for working hours
                $workingDays = [];
                $workingHoursMap = [];
                foreach ($workingHours as $index => $wh) {
                    if (!isset($wh['day'])) continue;
                    $day = strtolower($wh['day']);
                    if (in_array($day, $workingDays, true)) {
                        $validator->errors()->add("working_hours.{$index}.day", "Duplicate working hours entry for day: {$day}.");
                    }
                    $workingDays[] = $day;
                    $workingHoursMap[$day] = $wh;

                    // Working-hour order: opens_at must be earlier than closes_at
                    $isOpen = filter_var($wh['is_open'] ?? false, FILTER_VALIDATE_BOOLEAN);
                    if ($isOpen) {
                        $opensAt = $wh['opens_at'] ?? null;
                        $closesAt = $wh['closes_at'] ?? null;
                        if ($opensAt && $closesAt) {
                            try {
                                $opVal = \Illuminate\Support\Carbon::createFromFormat('H:i', $opensAt);
                                $clVal = \Illuminate\Support\Carbon::createFromFormat('H:i', $closesAt);
                                if ($opVal->greaterThanOrEqualTo($clVal)) {
                                    $validator->errors()->add("working_hours.{$index}.opens_at", "The opening time must be earlier than closing time.");
                                }
                            } catch (\Exception $e) {
                                // Handled by date_format rule
                            }
                        }
                    }
                }

                // Validate non-member booking schedule if enabled
                if ($allowNonMember) {
                    if (!is_array($nonMemberSchedule)) {
                        $validator->errors()->add('non_member_booking_schedule', 'The non-member booking schedule is required when non-member booking is allowed.');
                        return;
                    }

                    $nonMemberDays = [];
                    foreach ($nonMemberSchedule as $index => $nms) {
                        if (!isset($nms['day'])) continue;
                        $day = strtolower($nms['day']);
                        if (in_array($day, $nonMemberDays, true)) {
                            $validator->errors()->add("non_member_booking_schedule.{$index}.day", "Duplicate non-member booking schedule entry for day: {$day}.");
                        }
                        $nonMemberDays[] = $day;

                        $isAvailable = filter_var($nms['is_available'] ?? false, FILTER_VALIDATE_BOOLEAN);
                        $timeRanges = $nms['time_ranges'] ?? [];

                        // Closed-day rule: A closed club day cannot contain non-member booking ranges
                        $clubDayConfig = $workingHoursMap[$day] ?? null;
                        $isClubOpen = $clubDayConfig ? filter_var($clubDayConfig['is_open'] ?? false, FILTER_VALIDATE_BOOLEAN) : false;

                        if (!$isClubOpen) {
                            if ($isAvailable || !empty($timeRanges)) {
                                $validator->errors()->add("non_member_booking_schedule.{$index}.is_available", "A closed club day ({$day}) cannot contain non-member booking ranges.");
                            }
                            continue;
                        }

                        if ($isAvailable && is_array($timeRanges)) {
                            $sortedRanges = [];
                            foreach ($timeRanges as $rIdx => $range) {
                                $from = $range['from'] ?? null;
                                $to = $range['to'] ?? null;
                                if (!$from || !$to) continue;

                                try {
                                    $fromTime = \Illuminate\Support\Carbon::createFromFormat('H:i', $from);
                                    $toTime = \Illuminate\Support\Carbon::createFromFormat('H:i', $to);

                                    // Non-member range order: Each from value must be earlier than its corresponding to value
                                    if ($fromTime->greaterThanOrEqualTo($toTime)) {
                                        $validator->errors()->add("non_member_booking_schedule.{$index}.time_ranges.{$rIdx}.from", "The from time must be earlier than the to time.");
                                        continue;
                                    }

                                    // Within club hours: Every non-member time range must fall completely inside the club working hours for that day
                                    if (isset($clubDayConfig['opens_at']) && isset($clubDayConfig['closes_at'])) {
                                        $clubOpensAt = \Illuminate\Support\Carbon::createFromFormat('H:i', $clubDayConfig['opens_at']);
                                        $clubClosesAt = \Illuminate\Support\Carbon::createFromFormat('H:i', $clubDayConfig['closes_at']);

                                        if ($fromTime->lessThan($clubOpensAt) || $toTime->greaterThan($clubClosesAt)) {
                                            $validator->errors()->add("non_member_booking_schedule.{$index}.time_ranges.{$rIdx}.from", "The non-member booking window must fall completely within club working hours ({$clubDayConfig['opens_at']} - {$clubDayConfig['closes_at']}).");
                                        }
                                    }

                                    $sortedRanges[] = [
                                        'from' => $fromTime,
                                        'to' => $toTime,
                                        'rIdx' => $rIdx
                                    ];
                                } catch (\Exception $e) {
                                    // Handled by validation format rules
                                }
                            }

                            // No overlapping ranges: Multiple non-member ranges on the same day must not overlap
                            usort($sortedRanges, function ($a, $b) {
                                return $a['from'] <=> $b['from'];
                            });

                            for ($i = 0; $i < count($sortedRanges) - 1; $i++) {
                                $current = $sortedRanges[$i];
                                $next = $sortedRanges[$i + 1];
                                if ($current['to']->greaterThan($next['from'])) {
                                    $validator->errors()->add("non_member_booking_schedule.{$index}.time_ranges.{$next['rIdx']}.from", "Non-member booking time ranges must not overlap.");
                                }
                            }
                        }
                    }
                }
            });
        }

        if ($validator->fails()) {
            return $this->validationError($validator->errors()->toArray());
        }

        $logoPath = null;
        if ($request->hasFile('club_logo')) {
            $logoPath = $request->file('club_logo')->store('club-logos', 'public');
        }

        DB::beginTransaction();
        try {
            if ($isLegacy) {
                $allowed = filter_var($request->input('non_member_booking.allowed', false), FILTER_VALIDATE_BOOLEAN);
                $workingHoursString = $request->string('working_hours')->toString();
                $timezone = $allowed ? $request->input('non_member_booking.timezone') : null;

                $user = User::create([
                    'name' => $request->string('owner_manager_name')->toString(),
                    'email' => $email,
                    'phone' => $phone,
                    'password' => Hash::make($request->string('password')->toString()),
                    'role' => 'club',
                    'status' => 'otp_pending',
                    'otp_verified' => false,
                    'club_name' => $request->string('club_name')->toString(),
                    'owner_manager_name' => $request->string('owner_manager_name')->toString(),
                    'address' => $request->string('address')->toString(),
                    'city' => $request->string('city')->toString(),
                    'number_of_courts' => $request->integer('number_of_courts'),
                    'working_hours' => $workingHoursString,
                    'club_logo' => $logoPath,
                    'facilities' => $request->input('facilities', []),
                    
                    // Save booking policy fields
                    'non_member_booking_allowed' => $allowed,
                    'non_member_booking_start_time' => $allowed ? $request->input('non_member_booking.start_time') : null,
                    'non_member_booking_end_time' => $allowed ? $request->input('non_member_booking.end_time') : null,
                    'timezone' => $timezone,
                ]);

                // Create day-wise working hours schedule automatically
                // Parse working hours string to get times
                $start = '08:00';
                $end = '23:00';
                if ($workingHoursString && preg_match('/(\d{2}:\d{2})\s*-\s*(\d{2}:\d{2})/', $workingHoursString, $matches)) {
                    $start = $matches[1];
                    $end = $matches[2];
                }

                $daysOfWeek = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
                foreach ($daysOfWeek as $d) {
                    \App\Models\ClubWorkingHour::create([
                        'club_id' => $user->id,
                        'day' => $d,
                        'is_open' => true,
                        'opens_at' => $start,
                        'closes_at' => $end,
                    ]);
                }

                // Create non-member windows
                foreach ($daysOfWeek as $d) {
                    \App\Models\ClubNonMemberWindow::create([
                        'club_id' => $user->id,
                        'day' => $d,
                        'is_available' => $allowed,
                        'from_time' => $allowed ? $request->input('non_member_booking.start_time') : null,
                        'to_time' => $allowed ? $request->input('non_member_booking.end_time') : null,
                    ]);
                }
            } else {
                $allowed = filter_var($request->input('allow_non_member_booking', false), FILTER_VALIDATE_BOOLEAN);
                $timezone = $request->input('timezone');

                // Determine default working_hours string from the first open day for legacy code compatibility
                $workingHoursArray = $request->input('working_hours');
                $firstOpenDay = collect($workingHoursArray)->first(function ($wh) {
                    return filter_var($wh['is_open'] ?? false, FILTER_VALIDATE_BOOLEAN);
                });
                $workingHoursString = $firstOpenDay 
                    ? "{$firstOpenDay['opens_at']} - {$firstOpenDay['closes_at']}" 
                    : "08:00 - 23:00";

                // Save non_member_booking_start_time and non_member_booking_end_time from the first available day's first window (for legacy compatibility)
                $legacyStartTime = null;
                $legacyEndTime = null;
                if ($allowed && is_array($request->input('non_member_booking_schedule'))) {
                    $firstAvailDay = collect($request->input('non_member_booking_schedule'))->first(function ($nms) {
                        return filter_var($nms['is_available'] ?? false, FILTER_VALIDATE_BOOLEAN) && !empty($nms['time_ranges']);
                    });
                    if ($firstAvailDay && isset($firstAvailDay['time_ranges'][0])) {
                        $legacyStartTime = $firstAvailDay['time_ranges'][0]['from'];
                        $legacyEndTime = $firstAvailDay['time_ranges'][0]['to'];
                    }
                }

                $user = User::create([
                    'name' => $request->string('owner_manager_name')->toString(),
                    'email' => $email,
                    'phone' => $phone,
                    'password' => Hash::make($request->string('password')->toString()),
                    'role' => 'club',
                    'status' => 'otp_pending',
                    'otp_verified' => false,
                    'club_name' => $request->string('club_name')->toString(),
                    'owner_manager_name' => $request->string('owner_manager_name')->toString(),
                    'address' => $request->string('address')->toString(),
                    'city' => $request->string('city')->toString(),
                    'number_of_courts' => $request->integer('number_of_courts'),
                    'working_hours' => $workingHoursString,
                    'club_logo' => $logoPath,
                    'facilities' => $request->input('facilities', []),
                    
                    // Save booking policy fields
                    'non_member_booking_allowed' => $allowed,
                    'non_member_booking_start_time' => $legacyStartTime,
                    'non_member_booking_end_time' => $legacyEndTime,
                    'timezone' => $timezone,
                ]);

                // Create day-wise working hours schedule
                foreach ($workingHoursArray as $wh) {
                    \App\Models\ClubWorkingHour::create([
                        'club_id' => $user->id,
                        'day' => strtolower($wh['day']),
                        'is_open' => filter_var($wh['is_open'], FILTER_VALIDATE_BOOLEAN),
                        'opens_at' => $wh['opens_at'] ?? null,
                        'closes_at' => $wh['closes_at'] ?? null,
                    ]);
                }

                // Create non-member windows
                if ($allowed && is_array($request->input('non_member_booking_schedule'))) {
                    foreach ($request->input('non_member_booking_schedule') as $nms) {
                        $day = strtolower($nms['day']);
                        $isAvail = filter_var($nms['is_available'], FILTER_VALIDATE_BOOLEAN);
                        $timeRanges = $nms['time_ranges'] ?? [];

                        if ($isAvail && is_array($timeRanges) && !empty($timeRanges)) {
                            foreach ($timeRanges as $range) {
                                \App\Models\ClubNonMemberWindow::create([
                                    'club_id' => $user->id,
                                    'day' => $day,
                                    'is_available' => true,
                                    'from_time' => $range['from'],
                                    'to_time' => $range['to'],
                                ]);
                            }
                        } else {
                            \App\Models\ClubNonMemberWindow::create([
                                'club_id' => $user->id,
                                'day' => $day,
                                'is_available' => false,
                                'from_time' => null,
                                'to_time' => null,
                            ]);
                        }
                    }
                } else {
                    // Seed empty/unavailable windows for all days
                    $daysOfWeek = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
                    foreach ($daysOfWeek as $d) {
                        \App\Models\ClubNonMemberWindow::create([
                            'club_id' => $user->id,
                            'day' => $d,
                            'is_available' => false,
                            'from_time' => null,
                            'to_time' => null,
                        ]);
                    }
                }
            }

            $this->assignRoleIfPresent($user, 'club');
            $this->createOtp($user->email, 'registration');

            // Handle initial player verification requests transactionally
            if ($request->has('initial_player_ids') && is_array($request->input('initial_player_ids'))) {
                foreach ($request->input('initial_player_ids') as $playerId) {
                    ClubMembershipRequest::create([
                        'club_id' => $user->id,
                        'player_id' => $playerId,
                        'membership_number' => 'PENDING',
                        'status' => ClubMembershipRequest::STATUS_PENDING,
                    ]);
                }
            }

            // Handle initial player memberships (saved directly as approved) transactionally
            if ($request->has('members') && is_array($request->input('members'))) {
                foreach ($request->input('members') as $memberData) {
                    $membership = ClubMembership::create([
                        'club_id' => $user->id,
                        'player_id' => (int) $memberData['player_id'],
                        'membership_number' => $memberData['membership_number'],
                        'status' => ClubMembership::STATUS_APPROVED,
                        'approved_at' => now(),
                        'verification_mode' => 'club_registration',
                    ]);

                    // Write audit log
                    AuditLogger::log(
                        actorId: $user->id,
                        action: 'add_member',
                        entityType: ClubMembership::class,
                        entityId: $membership->id,
                        before: null,
                        after: $membership->toArray()
                    );
                }
            }

            DB::commit();
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
        }

        return response()->json([
            'success' => true,
            'message' => 'Club registered successfully. OTP sent to email.',
            'data' => [
                'user_id' => $user->id,
                'role' => 'club',
                'email' => $user->email,
                'status' => $user->status,
                'otp_verified' => false,
            ],
        ], 201);
    }

    public function verifyOtp(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'email' => ['required', 'email'],
            'otp' => ApiValidationRules::otp(),
            'purpose' => ['required', 'in:registration,forgot_password'],
        ]);

        if ($validator->fails()) {
            return $this->validationError($validator->errors()->toArray());
        }

        $email = strtolower($request->string('email')->toString());
        $otpRecord = DB::table('auth_otps')
            ->where('email', $email)
            ->where('purpose', $request->string('purpose')->toString())
            ->whereNull('verified_at')
            ->where('expires_at', '>', now())
            ->latest('id')
            ->first();

        if (! $otpRecord || ! Hash::check($request->string('otp')->toString(), $otpRecord->otp_hash)) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid or expired OTP.',
                'error_code' => 'INVALID_OTP',
            ], 422);
        }

        DB::table('auth_otps')->where('id', $otpRecord->id)->update(['verified_at' => now()]);
        $user = User::where('email', $email)->first();

        if (! $user) {
            return response()->json([
                'success' => false,
                'message' => 'User not found with this email.',
                'error_code' => 'USER_NOT_FOUND',
            ], 404);
        }

        if ($request->string('purpose')->toString() === 'registration') {
            $user->otp_verified = true;

            if ($user->role === 'player') {
                $user->status = 'profile_incomplete';
                $user->save();

                return response()->json([
                    'success' => true,
                    'message' => 'OTP verified successfully.',
                    'data' => [
                        'user_id' => $user->id,
                        'role' => 'player',
                        'status' => $user->status,
                        'otp_verified' => true,
                    ],
                ]);
            }

            $user->status = 'pending';
            $user->save();

            return response()->json([
                'success' => true,
                'message' => 'OTP verified successfully. Club profile is pending admin approval.',
                'data' => [
                    'user_id' => $user->id,
                    'role' => 'club',
                    'status' => $user->status,
                    'otp_verified' => true,
                ],
            ]);
        }

        return response()->json([
            'success' => true,
            'message' => 'OTP verified successfully.',
        ]);
    }

    public function resendOtp(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'email' => ['required', 'email'],
            'purpose' => ['required', 'in:registration,forgot_password'],
        ]);

        if ($validator->fails()) {
            return $this->validationError($validator->errors()->toArray());
        }

        $email = strtolower($request->string('email')->toString());
        $user = User::where('email', $email)->first();

        if (! $user) {
            return response()->json([
                'success' => false,
                'message' => 'User not found with this email.',
                'error_code' => 'USER_NOT_FOUND',
            ], 404);
        }

        $this->createOtp($email, $request->string('purpose')->toString());

        return response()->json([
            'success' => true,
            'message' => 'OTP resent successfully. Please check your email.',
        ]);
    }

    public function completePlayerProfile(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();

        if ($user->role !== 'player') {
            return response()->json([
                'success' => false,
                'message' => 'Only players can complete this profile.',
            ], 403);
        }

        $validator = Validator::make($request->all(), [
            'profile_image' => ['nullable', 'file', 'mimes:jpg,jpeg,png,webp'],
            'dob' => ApiValidationRules::dob(),
            'gender' => ApiValidationRules::gender(),
            'city' => ['required', 'string', 'max:100'],
            'playing_level' => ApiValidationRules::playingLevel(),
            'primary_hand' => ApiValidationRules::primaryHand(),
            'bio' => ['nullable', 'string', 'max:1000'],
        ]);

        if ($validator->fails()) {
            return $this->validationError($validator->errors()->toArray());
        }

        if ($request->hasFile('profile_image')) {
            $user->profile_image = $request->file('profile_image')->store('player-profiles', 'public');
        }

        $user->dob = $request->date('dob');
        $user->gender = $request->string('gender')->toString();
        $user->city = $request->string('city')->toString();
        $user->playing_level = $request->string('playing_level')->toString();
        $user->primary_hand = $request->string('primary_hand')->toString();
        $user->bio = $request->string('bio')->toString();
        $user->status = 'active';
        $user->save();

        return response()->json([
            'success' => true,
            'message' => 'Profile completed successfully.',
            'data' => [
                'user_id' => $user->id,
                'role' => 'player',
                'status' => 'active',
                'profile_completed' => true,
            ],
        ]);
    }

    public function login(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'email' => ['required', 'email'],
            'password' => ['required', 'string'],
            'role' => ['required', 'in:player,club'],
        ]);

        if ($validator->fails()) {
            return $this->validationError($validator->errors()->toArray());
        }

        $user = User::where('email', strtolower($request->string('email')->toString()))
            ->where('role', $request->string('role')->toString())
            ->first();

        if (! $user || ! Hash::check($request->string('password')->toString(), $user->password)) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid credentials.',
                'error_code' => 'INVALID_CREDENTIALS',
            ], 401);
        }

        if (! $user->otp_verified) {
            return response()->json([
                'success' => false,
                'message' => 'Please verify your email OTP before login.',
                'error_code' => 'OTP_NOT_VERIFIED',
            ], 403);
        }

        if ($user->status === 'suspended') {
            return response()->json([
                'success' => false,
                'message' => 'Your account has been suspended. Please contact support.',
                'error_code' => 'ACCOUNT_SUSPENDED',
            ], 403);
        }

        if ($user->role === 'club') {
            if ($user->status === 'pending') {
                return response()->json([
                    'success' => false,
                    'message' => 'Your club profile is pending admin approval.',
                    'error_code' => 'CLUB_PENDING_APPROVAL',
                ], 403);
            }

            if ($user->status === 'rejected') {
                return response()->json([
                    'success' => false,
                    'message' => 'Your club profile has been rejected by admin.',
                    'error_code' => 'CLUB_REJECTED',
                ], 403);
            }
        }

        $plainAccessToken = bin2hex(random_bytes(32));
        $plainRefreshToken = bin2hex(random_bytes(32));

        $user->api_access_token = hash('sha256', $plainAccessToken);
        $user->api_refresh_token = hash('sha256', $plainRefreshToken);
        $user->save();

        return response()->json([
            'success' => true,
            'message' => 'Login successful.',
            'data' => [
                'access_token' => $plainAccessToken,
                'refresh_token' => $plainRefreshToken,
                'user' => [
                    'id' => $user->id,
                    'role' => $user->role,
                    'email' => $user->email,
                    'status' => $user->status,
                    'otp_verified' => (bool) $user->otp_verified,
                    'profile_completed' => $this->isPlayerProfileCompleted($user),
                ],
            ],
        ]);
    }

    public function forgotPassword(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'email' => ['required', 'email'],
        ]);

        if ($validator->fails()) {
            return $this->validationError($validator->errors()->toArray());
        }

        $email = strtolower($request->string('email')->toString());
        $user = User::where('email', $email)->first();

        if (! $user) {
            return response()->json([
                'success' => false,
                'message' => 'User not found with this email.',
                'error_code' => 'USER_NOT_FOUND',
            ], 404);
        }

        if ($user->role === 'club' && $user->status === 'pending') {
            return response()->json([
                'success' => false,
                'message' => 'Your club profile is pending admin approval.',
                'error_code' => 'CLUB_PENDING_APPROVAL',
            ], 403);
        }

        $this->createOtp($email, 'forgot_password');

        return response()->json([
            'success' => true,
            'message' => 'OTP sent to your email for password reset.',
            'data' => [
                'email' => $email,
            ],
        ]);
    }

    public function verifyForgotPasswordOtp(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'email' => ['required', 'email'],
            'otp' => ApiValidationRules::otp(),
        ]);

        if ($validator->fails()) {
            return $this->validationError($validator->errors()->toArray());
        }

        $email = strtolower($request->string('email')->toString());
        $otpRecord = DB::table('auth_otps')
            ->where('email', $email)
            ->where('purpose', 'forgot_password')
            ->whereNull('verified_at')
            ->where('expires_at', '>', now())
            ->latest('id')
            ->first();

        if (! $otpRecord || ! Hash::check($request->string('otp')->toString(), $otpRecord->otp_hash)) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid or expired OTP.',
                'error_code' => 'INVALID_OTP',
            ], 422);
        }

        DB::table('auth_otps')->where('id', $otpRecord->id)->update(['verified_at' => now()]);
        $plainResetToken = bin2hex(random_bytes(24));

        DB::table('password_reset_otp_tokens')->insert([
            'email' => $email,
            'token_hash' => hash('sha256', $plainResetToken),
            'expires_at' => now()->addMinutes(15),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'OTP verified successfully. You can now reset your password.',
            'data' => [
                'reset_token' => $plainResetToken,
            ],
        ]);
    }

    public function resetPassword(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'reset_token' => ['required', 'string'],
            'new_password' => ['required', Password::min(8)],
            'confirm_password' => ['required', 'same:new_password'],
        ]);

        if ($validator->fails()) {
            return $this->validationError($validator->errors()->toArray());
        }

        $tokenHash = hash('sha256', $request->string('reset_token')->toString());
        $tokenRecord = DB::table('password_reset_otp_tokens')
            ->where('token_hash', $tokenHash)
            ->whereNull('used_at')
            ->where('expires_at', '>', now())
            ->latest('id')
            ->first();

        if (! $tokenRecord) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid or expired reset token.',
                'error_code' => 'INVALID_RESET_TOKEN',
            ], 422);
        }

        $user = User::where('email', $tokenRecord->email)->first();
        if (! $user) {
            return response()->json([
                'success' => false,
                'message' => 'User not found with this email.',
                'error_code' => 'USER_NOT_FOUND',
            ], 404);
        }

        if (Hash::check($request->string('new_password')->toString(), $user->password)) {
            return response()->json([
                'success' => false,
                'message' => 'Password cannot be same as current password.',
                'error_code' => ApiErrorCode::VALIDATION_ERROR,
            ], 422);
        }

        $user->password = Hash::make($request->string('new_password')->toString());
        $user->save();

        DB::table('password_reset_otp_tokens')->where('id', $tokenRecord->id)->update(['used_at' => now()]);

        return response()->json([
            'success' => true,
            'message' => 'Password reset successfully. Please login with your new password.',
        ]);
    }

    public function changePassword(Request $request): JsonResponse
    {
        $user = $request->user();

        if (! $user) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized. Token is missing or invalid.',
                'error_code' => ApiErrorCode::UNAUTHORIZED,
                'errors' => new \stdClass(),
            ], 401);
        }

        $validator = Validator::make($request->all(), [
            'current_password' => ['required', 'string'],
            'new_password' => ['required', Password::min(8), 'different:current_password'],
            'confirm_password' => ['required', 'same:new_password'],
        ]);

        if ($validator->fails()) {
            return $this->validationError($validator->errors()->toArray());
        }

        if (! Hash::check($request->string('current_password')->toString(), $user->password)) {
            return response()->json([
                'success' => false,
                'message' => 'Current password is incorrect.',
                'error_code' => ApiErrorCode::INVALID_CREDENTIALS,
            ], 422);
        }

        $user->password = Hash::make($request->string('new_password')->toString());
        $user->save();

        return response()->json([
            'success' => true,
            'message' => 'Password changed successfully.',
        ]);
    }

    public function deleteAccount(Request $request): JsonResponse
    {
        $user = $request->user();

        if (! $user) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized. Token is missing or invalid.',
                'error_code' => ApiErrorCode::UNAUTHORIZED,
                'errors' => new \stdClass(),
            ], 401);
        }

        if ($user->role === 'club') {
            if ($user->tournaments()->whereIn('status', ['open', 'full', 'closed'])->exists()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Club cannot be deleted while it has an active tournament.',
                    'error_code' => ApiErrorCode::VALIDATION_ERROR,
                ], 422);
            }

            if ($user->bookingsAsClub()->whereIn('booking_status', ['pending', 'confirmed'])->exists()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Club cannot be deleted while it has an active booking.',
                    'error_code' => ApiErrorCode::VALIDATION_ERROR,
                ], 422);
            }
        }

        $filesToDelete = array_values(array_filter([
            $user->profile_image,
            $user->club_logo,
        ]));

        DB::transaction(function () use ($user) {
            DB::table('court_time_slots')
                ->whereIn('booking_id', function ($query) use ($user) {
                    $query->select('id')
                        ->from('bookings')
                        ->where('player_id', $user->id);
                })
                ->update([
                    'status' => 'available',
                    'booking_id' => null,
                    'updated_at' => now(),
                ]);

            DB::table('auth_otps')->where('email', $user->email)->delete();
            DB::table('password_reset_otp_tokens')->where('email', $user->email)->delete();

            $user->roles()->detach();
            $user->delete();
        });

        foreach ($filesToDelete as $path) {
            if (! str_starts_with($path, 'http://') && ! str_starts_with($path, 'https://')) {
                Storage::disk('public')->delete($path);
            }
        }

        return response()->json([
            'success' => true,
            'message' => 'Account deleted successfully.',
        ]);
    }

    private function createOtp(string $email, string $purpose): void
    {
        $otp = (string) random_int(100000, 999999);

        // Store OTP in database
        DB::table('auth_otps')->insert([
            'email' => $email,
            'purpose' => $purpose,
            'otp_hash' => Hash::make($otp),
            'expires_at' => now()->addMinutes(10),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Get user name if exists
        $user = User::where('email', $email)->first();
        $userName = $user ? $user->name : 'User';

        // Send OTP email
        try {
            Mail::to($email)->send(
                new OtpMail($otp, $purpose, $userName)
            );

            logger()->info('Squash Pro OTP sent successfully', [
                'email' => $email,
                'purpose' => $purpose,
            ]);
        } catch (\Exception $e) {
            logger()->error('Failed to send OTP email', [
                'email' => $email,
                'purpose' => $purpose,
                'error' => $e->getMessage(),
            ]);

            // Log OTP for development (remove in production)
            if (config('app.env') !== 'production') {
                logger()->info('OTP generated (email failed)', [
                    'email' => $email,
                    'otp' => $otp,
                ]);
            }
        }
    }

    private function assignRoleIfPresent(User $user, string $role): void
    {
        if (Role::where('name', $role)->exists()) {
            $user->assignRole($role);
        }
    }

    private function isPlayerProfileCompleted(User $user): bool
    {
        if ($user->role !== 'player') {
            return false;
        }

        return $user->status === 'active'
            && filled($user->dob)
            && filled($user->gender)
            && filled($user->city)
            && filled($user->playing_level)
            && filled($user->primary_hand);
    }

    private function validationError(array $errors): JsonResponse
    {
        return response()->json([
            'success' => false,
            'message' => 'Validation failed.',
            'error_code' => ApiErrorCode::VALIDATION_ERROR,
            'errors' => $errors,
        ], 422);
    }
}
